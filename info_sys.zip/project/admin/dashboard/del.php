
<?php
include '../../config.php';


if(isset($_POST['rdel'])) {
	
        $chas_no=$_POST['chas_no'];
     
    
        
            $sql = "DELETE from rto where chas_no='$chas_no'";
            $result = mysqli_query($conn, $sql);
            if ($result) {
           echo "<script>alert(' Details deleted.')</script>";
                header("Location: rto.php");
    
            } else {
                 echo "<script>alert('Woops! Something Went Wrong.')</script>";
        }
    
       }





if(isset($_POST['odel'])) {
	
        $off_id=$_POST['off_id'];
     
    
        
            $sql = "DELETE from officer where off_id='$off_id'";
            $result = mysqli_query($conn, $sql);
            if ($result) {
           echo "<script>alert(' Details deleted.')</script>";
                header("Location: officer.php");
    
            } else {
                 echo "<script>alert('Woops! Something Went Wrong.')</script>";
        }
    
       }



       if (isset($_POST['ndel'])) {
	
        $ch=$_POST['chas_no'];
       


    
        $sql = "DELETE from notice where chas_no='$ch'";

            $result = mysqli_query($conn, $sql);
            if ($result) {
                echo "<script>alert(' Details Deleted.')</script>";
                header("Refresh:0; url=../../officer/dashboard/");
    
            } else {
                echo "<script>alert('Woops! Something Went Wrong.')</script>";
            }
        }
            



       if (isset($_POST['andel'])) {
	
        $ch=$_POST['chas_no'];
       
    
    
    
    
        $sql = "DELETE from notice where chas_no='$ch'";

            $result = mysqli_query($conn, $sql);
            if ($result) {
                echo "<script>alert(' Details Deleted.')</script>";
                header("Refresh:0; url=../../officer/dashboard/index.php");
    
            } else {
                echo "<script>alert('Woops! Something Went Wrong.')</script>";
            }
    
        }
    

        
       if (isset($_POST['up_del'])) {
	
        $ch=$_POST['chas_no'];
       
    
    
    
    
        $sql = "DELETE from upload where chas_no='$ch'";

            $result = mysqli_query($conn, $sql);
            if ($result) {
                echo "<script>alert(' Details Deleted.')</script>";
                header("Refresh:0; url=../../officer/dashboard/index.php");
    
            } else {
                echo "<script>alert('Woops! Something Went Wrong.')</script>";
            }
    
        }
    
            

        
       if (isset($_POST['a_up_del'])) {
	
        $ch=$_POST['chas_no'];
       
    
    
    
    
        $sql = "DELETE from upload where chas_no='$ch'";

            $result = mysqli_query($conn, $sql);
            if ($result) {
                echo "<script>alert(' Details Deleted.')</script>";
                header("Refresh:0; url=../../officer/dashboard/index.php");
    
            } else {
                echo "<script>alert('Woops! Something Went Wrong.')</script>";
            }
    
        }
    
    
    

    
    



       ?>
    
    


    
    
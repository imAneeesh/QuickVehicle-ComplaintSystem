<?php 
include '../../config.php';


session_start();

$off_id=$_SESSION['off_id'];


if (isset($_POST['submit'])) {
	$reg_no = $_POST['reg_no'];
	$veh_name = $_POST['veh_name'];
	$owner_name = $_POST['owner_name'];
	$chas_no = $_POST['chas_no'];
    $off_id = $_SESSION['off_id'];
    $veh_color = $_POST['veh_color'];

    $sql = "SELECT * FROM upload WHERE reg_no='$reg_no'";
    $result = mysqli_query($conn, $sql);

    if (!$result->num_rows > 0) {


      $sql2 = "SELECT email FROM `complaints` WHERE chas_no='$chas_no'";
      $result2 = mysqli_query($conn, $sql2);
      $row = $result2->fetch_assoc();
      $email = $row['email'];


        $sql = "INSERT INTO upload 
        VALUES ('$chas_no', '$reg_no','$veh_name','$veh_color','$owner_name','$off_id','pending','$email')";
        $result = mysqli_query($conn, $sql);
        if ($result) {
            echo "<script>alert('Vehicle Details Uploaded.')</script>";
           
        } else {
            echo "<script>alert('Woops! Something Went Wrong.')</script>";
        }
    } else 
    {
        echo "<script>alert('!!! Vehicle Found on the DATABASE !!!.')</script>";
        header("Refresh:0; url=inform.php");
    }

}
?>


<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Upload</title>
  <link rel="stylesheet" href="./um_style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<head>
  <link href="https://fonts.googleapis.com/css2?family=Oswald&display=swap" rel="stylesheet">
 <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>

  <body>
    <input type="checkbox" id="active">
    <label for="active" class="menu-btn"><i class="fas fa-bars"></i></label>
    <div class="wrapper">
      <ul>
<li><a href="index.php">Home</a></li>
<li><a href="inform.php">Inform Owner</a></li>
<li><a href="logout.php">Logout</a></li>

</ul>
</div>
<!-- <div class="content"> -->
     

        
<div class="container">
		<form action="upload.php" method="POST" class="login-email">
            <p class="login-text" style="font-size: 2rem; font-weight: 800;">Upload Vehicle Information</p>
			<div class="input-group">
				<input type="text" placeholder="Registerarion Number" name="reg_no" required>
			</div>
            <div class="input-group">
				<input type="text" placeholder="Chassis No" name="chas_no" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Vehicle Name Name" name="veh_name" required>
			</div>
			<div class="input-group">
				<input type="text" placeholder="Owner Name" name="owner_name">
            </div>
          
            <div class="input-group">
				<input type="text" placeholder="Vehicle Color" name="veh_color">
			</div>
			<div class="input-group">
				<button name="submit" class="btn">Upload</button>
			</div>
		</form>
	</div>

<!-- <</div> -->
</body>
<!-- partial -->
  <script  src="./um_script.js"></script>

</body>
</html>




        
<style>

@import url('https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap');

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Poppins', sans-serif;
}

body {
    width: 100%;
    min-height: 100vh;
    background-image: linear-gradient(rgba(0,0,0,.5), rgba(0,0,0,.5)), url(bg.jpg);
    background-position: center;
    background-size: cover;
    justify-content: center;
    align-items: center;
}

.container {
    margin-left: auto;
  margin-right: auto;
    border: 3px solid black;
    width: 400px;
    min-height: 400px;
    background: #FFF;
    border-radius: 5px;
    box-shadow: 0 0 5px rgba(0,0,0,.3);
    padding: 40px 30px;
}

.container .login-text {
    color: #111;
    font-weight: 500;
    font-size: 1.1rem;
    text-align: center;
    margin-bottom: 20px;
    display: block;
    text-transform: capitalize;
}

.container .login-social {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(50%, 1fr));
    margin-bottom: 25px;
}

.container .login-social a {
    padding: 12px;
    margin: 10px;
    border-radius: 3px;
    box-shadow: 0 0 5px rgba(0,0,0,.3);
    text-decoration: none;
    font-size: 1rem;
    text-align: center;
    color: #FFF;
    transition: .3s;
}

.container .login-social a i {
    margin-right: 5px;
}

.container .login-social a.facebook {
    background: #4267B2;
}

.container .login-social a.twitter {
    background: #1DA1F2;
}

.container .login-social a.google-plus {
    background: #db4a39;
}

.container .login-social a.linkedin {
    background: #0e76a8;
}

.container .login-social a.facebook:hover {
    background: #3d5fa3;
}

.container .login-social a.twitter:hover {
    background: #1991db;
}

.container .login-social a.google-plus:hover {
    background: #ca4334;
}

.container .login-social a.linkedin:hover {
    background: #0b5c81;
}

.container .login-email .input-group {
    width: 100%;
    height: 50px;
    margin-bottom: 25px;
}

.container .login-email .input-group input {
    width: 100%;
    height: 100%;
    border: 2px solid #e7e7e7;
    padding: 15px 20px;
    font-size: 1rem;
    border-radius: 30px;
    background: transparent;
    outline: none;
    transition: .3s;
}

.container .login-email .input-group input:focus, .container .login-email .input-group input:valid {
    border-color: #a29bfe;
}

.container .login-email .input-group .btn {
    display: block;
    width: 100%;
    padding: 15px 20px;
    text-align: center;
    border: none;
    background: #a29bfe;
    outline: none;
    border-radius: 30px;
    font-size: 1.2rem;
    color: #FFF;
    cursor: pointer;
    transition: .3s;
}

.container .login-email .input-group .btn:hover {
    transform: translateY(-5px);
    background: #6c5ce7;
}

.login-register-text {
    color: #111;
    font-weight: 600;
}

.login-register-text a {
    text-decoration: none;
    color: #6c5ce7;
}

@media (max-width: 430px) {
    .container {
        width: 300px;
    }
    .container .login-social {
        display: block;
    }
    .container .login-social a {
        display: block;
    }
}
</style>
    
        <script type="text/javascript" src="mobile.js"></script>
    </body>
</html>
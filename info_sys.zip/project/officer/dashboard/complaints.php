
<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Officer</title>
  <link rel="stylesheet" href="./um_style.css">

</head>
<body>
<!-- partial:index.partial.html -->
<head>
  <link href="https://fonts.googleapis.com/css2?family=Oswald&display=swap" rel="stylesheet">
 <link href="https://fonts.googleapis.com/css2?family=Lato&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </head>

  <body>
    <input type="checkbox" id="active">
    <label for="active" class="menu-btn"><i class="fas fa-bars"></i></label>
    <div class="wrapper">
      <ul>
<li><a href="index.php">Home</a></li>
<li><a href="logout.php">Logout</a></li>

</ul>
</div>
<div class="content">
      <div class="title">

COMPLAINTS
<br>

<?php 
include '../../config.php';


session_start();


$sql = "SELECT * from  complaints";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
       echo " Registration Number: " . $row["reg_no"]. " <br>Chassis Number: " . $row["chas_no"]. "<br>Owner Name: " . $row["owner_name"]." <br>Vehicle Name: " . $row["veh_name"].  " <br>Description: " . $row["description"]."<br><br><br>";
    }
} else {
    echo "No Complaints Found in the Database.";
}
$conn->close();
?>

  
</dl>
<style>
    .container {
                        /* Content is center horizontally */
                        align-items: center;
                        display: flex;

                        /*
    The property name will stick to the left, and the value
    will stick to the right
    */
                        justify-content: space-between;

                        border-bottom: 1px solid rgba(0, 0, 0, 0.3);

                        /* Spacing */
                        margin: 0px;
                        padding: 8px 0px;
                    }
    </style>


        <script type="text/javascript" src="mobile.js"></script>
    </body>
</html>


      
</div>

</div>
</body>
<!-- partial -->
  <script  src="./um_script.js"></script>

</body>
</html>
